// global map variable
var mapWiscTemps;

// function to instantiate Leaflet map object
function createMap(){
    //create map
    mapWiscTemps = L.map('mapWiscTemps', {
        center: [44.4308975, -89.6884637],
        zoom: 7
    });

    //add base tilelayer
    // uses USGS topo map
    L.tileLayer('https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}', {
	maxZoom: 20,
	attribution: 'Tiles courtesy of the <a href="https://usgs.gov/">U.S. Geological Survey</a>'
    }).addTo(mapWiscTemps);

    //call getData function
    getData();
};

//function to attach popups to each mapped feature
function onEachFeature(feature, layer) {
    //no property named popupContent; instead, create html string with all properties
    var popupContent = "";
    if (feature.properties) {
        //loop to add feature property names and values to html string
        for (var property in feature.properties){
            if (property.includes('TAVG')) {  // limit table so it only includes the ave temp field
                popupContent += "<p>" + property + ": " + feature.properties[property] + "</p>";
            }
        }
        layer.bindPopup(popupContent);
    };
};

//function to retrieve the data and place it on the map
function getData(){
    //load data
    fetch("data/wiscTemps.geojson")
        .then(function(response){
            return response.json();
        })
        .then(function(json){
            //create marker options
            var geojsonMarkerOptions = {
                radius: 8,
                fillColor: "#ff7800",
                color: "#000",
                weight: 1,
                opacity: 1,
                fillOpacity: 0.8
            };
            //create a Leaflet GeoJSON layer and add it to the map
            L.geoJson(json, {
                pointToLayer: function (feature, latlng){
                    return L.circleMarker(latlng, geojsonMarkerOptions);  // creates circle markers
                },
                onEachFeature: onEachFeature  // adds properties to pop-up
            }).addTo(mapWiscTemps);
        })  
};

document.addEventListener('DOMContentLoaded',createMap);